<?php
/**
 * Plugin Name: Mon Premier Plugin
 * Plugin URI:  https://monsite.com/mon-plugin
 * Description: Un plugin simple pour apprendre à ajouter du contenu aux articles.
 * Version:     1.0
 * Author:      Votre Nom
 * Author URI:  https://monsite.com
 * License:     GPL2
 */

// Sécurité : Empêcher l'accès direct au fichier si on l'appelle en dehors de WordPress
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * On passe d'un Filtre (Filter) à une Action (Action)
 * Au lieu de modifier une variable ($content), on affiche directement le HTML avec un echo
 */
function mpp_afficher_bloc_footer() {
    ?>
    <div style="
        position: fixed; 
        bottom: 0; 
        left: 0; 
        width: 100%; 
        background-color: #e6ffe6; 
        border-top: 3px solid #00cc66; 
        color: #006633; 
        padding: 15px; 
        text-align: center; 
        font-family: sans-serif;
        font-weight: bold;
        z-index: 99999;
        box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
    ">
        Mon espace pour la publicité ou les infos de contact
    </div>
    <?php
}

// On change la toute dernière ligne : on utilise add_action sur 'wp_footer'
add_action( 'wp_footer', 'mpp_afficher_bloc_footer' );