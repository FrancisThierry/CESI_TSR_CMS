<?php
/**
 * Plugin Name: Words Count Plugin
 * Plugin URI: https://monsite.com
 * Description: Affiche le nombre de mots et le temps de lecture à la fin des articles.
 * Version: 2.0
 * Author: Thierry Boulanger
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Charge le CSS du plugin.
 */
function wcp_enqueue_styles() {

    wp_enqueue_style(
        'wcp-style',
        plugin_dir_url( __FILE__ ) . 'assets/css/words-count.css',
        array(),
        '2.0'
    );

}
add_action( 'wp_enqueue_scripts', 'wcp_enqueue_styles' );

/**
 * Compte les mots du contenu.
 */
function wcp_get_word_count( $post_id ) {

    $content = get_post_field( 'post_content', $post_id );

    if ( empty( $content ) ) {
        return 0;
    }

    // Supprime les shortcodes
    $content = strip_shortcodes( $content );

    // Supprime les commentaires Gutenberg
    $content = preg_replace( '/<!--(.|\s)*?-->/', ' ', $content );

    // Supprime le HTML
    $content = wp_strip_all_tags( $content );

    // Décode les entités HTML
    $content = html_entity_decode(
        $content,
        ENT_QUOTES | ENT_HTML5,
        'UTF-8'
    );

    // Normalise les espaces
    $content = preg_replace(
        '/\s+/u',
        ' ',
        trim( $content )
    );

    if ( empty( $content ) ) {
        return 0;
    }

    // Comptage UTF-8
    preg_match_all(
        '/[\p{L}\p{N}]+(?:[\'’-][\p{L}\p{N}]+)*/u',
        $content,
        $matches
    );

    return count( $matches[0] );
}

/**
 * Temps de lecture.
 */
function wcp_get_reading_time( $word_count ) {

    $minutes = max(
        1,
        ceil( $word_count / 200 )
    );

    return sprintf(
        _n(
            '%d minute de lecture',
            '%d minutes de lecture',
            $minutes,
            'words-count-plugin'
        ),
        $minutes
    );
}

/**
 * Ajoute les statistiques à la fin de l'article.
 */
function wcp_append_stats( $content ) {

    if ( is_admin() ) {
        return $content;
    }

    if ( ! is_single() ) {
        return $content;
    }

    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    global $post;

    $word_count  = wcp_get_word_count( $post->ID );
    $reading_time = wcp_get_reading_time( $word_count );

    $html  = '<div class="wcp-stats">';
    $html .= '<hr>';
    $html .= '<p><strong>📖 Nombre de mots :</strong> ';
    $html .= esc_html( $word_count );
    $html .= '</p>';

    $html .= '<p><strong>⏱ Temps de lecture :</strong> ';
    $html .= esc_html( $reading_time );
    $html .= '</p>';
    $html .= '</div>';

    return $content . $html;
}

add_filter( 'the_content', 'wcp_append_stats', 999 );

